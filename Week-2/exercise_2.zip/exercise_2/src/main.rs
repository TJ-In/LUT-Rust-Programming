use std::io;

fn main() {
	let mut number = 0;
	loop {
	    println!("| 1) Reset | 2) Addition | 3) Retraction | 4) Multiplication | 5) Division | 6) Print | 0) End program |");
		let mut input = String::new();
		io::stdin().read_line(&mut input).expect("Failed to read user input.");
		match input.trim() {
			"1" => reset(&mut number),
			"2" => addition(&mut number),
			"3" => retraction(&mut number),
			"4" => multiplication(&mut number),
			"5" => division(&mut number),
			"6" => print(&number),
			"0" => {println!("Ending the program."); break; },
			_ => println!("Invalid input. Try again."),
		}
	}
}

fn reset(n: &mut i32) {
	*n = 0;
}
fn addition(n: &mut i32) {
	let add = read_number();
	*n += add;
}
fn retraction(n: &mut i32) {
	let sub = read_number();
	*n -= sub;
}
fn multiplication(n: &mut i32) {
	let mul = read_number();
	*n = *n * mul;
}
fn division(n: &mut i32) {
	let div = read_number();
	*n = *n / div;
}
fn print(n: &i32) {
	println!("Current number: {}", n);
}
fn read_number() -> i32 {
	println!("What number?");
	let mut input = String::new();
	io::stdin().read_line(&mut input).expect("Failed to read user input.");
	let number: i32 = input.trim().parse().expect("Failed to parse correct value");
	number
}