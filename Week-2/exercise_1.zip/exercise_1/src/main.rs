use std::io;
fn main() {
    let default: &str = "I want to be changed.";
    let mut s = String::from(default);
    loop {
        println!(
            "| 1) Reset | 2) Remove a word | 3) Add a word | 4) Print string | 0) End program |"
        );
        let mut input = String::new();
	io::stdin().read_line(&mut input).expect("Failed to read user input.");
	match input.trim() {
		"1" => s = create_default(default),
		"2" => remove_latest_word(&mut s),
		"3" => add_word(&mut s),
		"4" => println!("{}", &s),
		"0" => break,
		_ => println!("Parsing error. Was the input a number?"),
	}
    }
}
fn create_default(s: &str) -> String {
    s.to_string()
}
fn remove_latest_word(s: &mut String) {
    let mut vec = s.split_whitespace().collect::<Vec<_>>();
    vec.pop();
    *s = vec.join(" ");
}
fn add_word(s: &mut String) {
	let mut new = String::new();
	println!("The new word: ");
	io::stdin().read_line(&mut new).expect("Failed to read user input.");
	*s += &(" ".to_owned() + &new.trim());
}