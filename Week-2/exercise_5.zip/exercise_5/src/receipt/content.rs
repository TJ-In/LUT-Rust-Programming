use super::product::StoreProduct;

pub const PRODUCT_1_NAME: &str = "Zbox 720";
pub const PRODUCT_2_NAME: &str = "GPU - AND Random RT6600";
pub const PRODUCT_3_NAME: &str = "Potato";

pub struct ReceiptContent {
    pub products: Vec<StoreProduct>,
    pub store: String,
}

impl ReceiptContent {
    pub fn new()->Self {
        Self {
            products: vec![],
            store: String::new(),
        }
    }
}