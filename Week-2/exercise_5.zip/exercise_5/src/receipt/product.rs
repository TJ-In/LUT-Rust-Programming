use super::content::*;

#[derive(Clone, PartialEq)]
pub struct StoreProduct {
    pub name: String,
    pub price: i32,
}
pub fn create_products() -> Vec<StoreProduct> {
    vec![
        StoreProduct {
            name: PRODUCT_1_NAME.to_string(),
            price: 600,
        },
        StoreProduct {
            name: PRODUCT_2_NAME.to_string(),
            price: 200,
        },
        StoreProduct {
            name: PRODUCT_3_NAME.to_string(),
            price: 1,
        },
    ]
}

impl StoreProduct {
    pub fn new() -> Self {
        Self {
            name: String::new(),
            price: 0,
        }
    }
}
