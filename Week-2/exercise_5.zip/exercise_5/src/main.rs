use std::io;
mod receipt;
use receipt::product::*;
use std::fs;

pub type Error = Box<dyn std::error::Error>;

use crate::receipt::content::ReceiptContent;


fn main() {
    let mut receipt = ReceiptContent::new();
    receipt.store = "Imaginary Town General Store".to_string();

    loop {
        println!("| 1) Add to cart | 2) Remove most recent product | 3) Purchase |");
        let mut input = String::new();
        io::stdin()
            .read_line(&mut input)
            .expect("Failed to read user input.");
        match input.trim() {
            "1" => receipt.products.push(add_to_cart()),
            "2" => remove_last_item(&mut receipt),
            "3" => {
                complete_purchase(&receipt).expect("Failed to print receipt.");
                break;
            },
            _ => println!("Command unknown."),
        }
    }
}

fn add_to_cart() -> StoreProduct {
    let mut product = StoreProduct::new();
    println!("Which product would you like to add?");
    let products = create_products();
    let mut product_number = 0;
    for p in &products {
        product_number += 1;
        println!("{}) {} | Price - {}", product_number, p.name, p.price);
    }
    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read user input.");
    match input.trim() {
        "1" => product = products[0].clone(),
        "2" => product = products[1].clone(),
        "3" => product = products[2].clone(),
        _ => println!("Command unknown."),
    }
    product
}
fn remove_last_item(r: &mut ReceiptContent) {
    match r.products.pop() {
        Some(_) => (),
        None => println!("Cart is empty."),
    }
}
fn complete_purchase(r: &ReceiptContent) -> Result<(), Error> {
    let mut total = 0;
    for prod in &r.products {
        total += prod.price;
    }


   let products: Vec<String> =
    r.products
    .iter()
    .map(|item| {
        let amount = r.products.iter().filter(|i| **i == *item).count();
        format!{"{} ({}) - {}€", item.name, amount, item.price}
})
    .collect();
    
    fs::write("receipt.txt", format!(
        "{}\n------------------------------\n{}\n------------------------------\nFinal price: {}€\n------------------------------\n",
        r.store, products.join("\n"), total))?;
    println!("Thank you for your purchase!");
    Ok(())
}
