use std::io;
fn main() {
    let var1 = "rust";
    let var2 = "no";

    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Error");
    let input = input.trim().to_ascii_lowercase();

    if input == var1 {
        println!("So you appreciate Rust? That's great! Thank you!");
    } else if input == var2 {
        println!("So you like nothing? Alright then... :)");
    } else {
        println!("It seems that you like {input}.");
    }
}
